"""DynamoDB service for data operations."""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import uuid
import json
from decimal import Decimal

from ..config import settings


class DynamoDBService:
    """Service for DynamoDB operations."""
    
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name=settings.aws_region)
        self.users_table = self.dynamodb.Table(settings.users_table)
        self.lessons_table = self.dynamodb.Table(settings.lessons_table)
        self.micro_lessons_table = self.dynamodb.Table(settings.micro_lessons_table)
        self.quizzes_table = self.dynamodb.Table(settings.quizzes_table)
        self.user_engagement_table = self.dynamodb.Table(settings.user_engagement_table)
        self.chat_history_table = self.dynamodb.Table(settings.chat_history_table)
    
    def _serialize_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert Python types to DynamoDB compatible types."""
        if isinstance(item, dict):
            return {k: self._serialize_item(v) for k, v in item.items()}
        elif isinstance(item, list):
            return [self._serialize_item(i) for i in item]
        elif isinstance(item, datetime):
            return item.isoformat()
        elif isinstance(item, float):
            return Decimal(str(item))
        else:
            return item
    
    def _deserialize_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert DynamoDB types to Python types."""
        if isinstance(item, dict):
            return {k: self._deserialize_item(v) for k, v in item.items()}
        elif isinstance(item, list):
            return [self._deserialize_item(i) for i in item]
        elif isinstance(item, Decimal):
            return float(item)
        else:
            return item
    
    # User operations
    async def create_user(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new user."""
        user_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        
        item = {
            'user_id': user_id,
            'created_at': now.isoformat(),
            'updated_at': now.isoformat(),
            **user_data
        }
        
        serialized_item = self._serialize_item(item)
        self.users_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get user by ID."""
        response = self.users_table.get_item(Key={'user_id': user_id})
        return self._deserialize_item(response.get('Item')) if 'Item' in response else None
    
    async def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get user by email using GSI."""
        response = self.users_table.query(
            IndexName='EmailIndex',
            KeyConditionExpression=Key('email').eq(email)
        )
        items = response.get('Items', [])
        return self._deserialize_item(items[0]) if items else None
    
    async def update_user(self, user_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update user data."""
        updates['updated_at'] = datetime.now(timezone.utc).isoformat()
        
        update_expression = "SET "
        expression_values = {}
        
        for key, value in updates.items():
            update_expression += f"#{key} = :{key}, "
            expression_values[f":{key}"] = self._serialize_item(value)
        
        update_expression = update_expression.rstrip(", ")
        expression_names = {f"#{key}": key for key in updates.keys()}
        
        response = self.users_table.update_item(
            Key={'user_id': user_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_names,
            ExpressionAttributeValues=expression_values,
            ReturnValues='ALL_NEW'
        )
        
        return self._deserialize_item(response['Attributes'])
    
    # Lesson operations
    async def create_lesson(self, lesson_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new lesson."""
        lesson_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        
        item = {
            'lesson_id': lesson_id,
            'created_at': now.isoformat(),
            'updated_at': now.isoformat(),
            **lesson_data
        }
        
        serialized_item = self._serialize_item(item)
        self.lessons_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_lesson(self, lesson_id: str) -> Optional[Dict[str, Any]]:
        """Get lesson by ID."""
        response = self.lessons_table.get_item(Key={'lesson_id': lesson_id})
        return self._deserialize_item(response.get('Item')) if 'Item' in response else None
    
    async def get_user_lessons(self, user_id: str) -> List[Dict[str, Any]]:
        """Get all lessons for a user."""
        response = self.lessons_table.query(
            IndexName='UserLessonsIndex',
            KeyConditionExpression=Key('user_id').eq(user_id)
        )
        return [self._deserialize_item(item) for item in response.get('Items', [])]
    
    async def update_lesson(self, lesson_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update lesson data."""
        updates['updated_at'] = datetime.now(timezone.utc).isoformat()
        
        update_expression = "SET "
        expression_values = {}
        
        for key, value in updates.items():
            update_expression += f"#{key} = :{key}, "
            expression_values[f":{key}"] = self._serialize_item(value)
        
        update_expression = update_expression.rstrip(", ")
        expression_names = {f"#{key}": key for key in updates.keys()}
        
        response = self.lessons_table.update_item(
            Key={'lesson_id': lesson_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_names,
            ExpressionAttributeValues=expression_values,
            ReturnValues='ALL_NEW'
        )
        
        return self._deserialize_item(response['Attributes'])
    
    # Micro-lesson operations
    async def create_micro_lesson(self, micro_lesson_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new micro-lesson."""
        micro_lesson_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        
        item = {
            'micro_lesson_id': micro_lesson_id,
            'created_at': now.isoformat(),
            'updated_at': now.isoformat(),
            **micro_lesson_data
        }
        
        serialized_item = self._serialize_item(item)
        self.micro_lessons_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_lesson_micro_lessons(self, lesson_id: str) -> List[Dict[str, Any]]:
        """Get all micro-lessons for a lesson, ordered by sequence."""
        response = self.micro_lessons_table.query(
            IndexName='LessonMicroLessonsIndex',
            KeyConditionExpression=Key('lesson_id').eq(lesson_id)
        )
        items = [self._deserialize_item(item) for item in response.get('Items', [])]
        return sorted(items, key=lambda x: x.get('sequence_number', 0))
    
    # Quiz operations
    async def create_quiz(self, quiz_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new quiz."""
        quiz_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        
        item = {
            'quiz_id': quiz_id,
            'created_at': now.isoformat(),
            'updated_at': now.isoformat(),
            **quiz_data
        }
        
        serialized_item = self._serialize_item(item)
        self.quizzes_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_micro_lesson_quiz(self, micro_lesson_id: str) -> Optional[Dict[str, Any]]:
        """Get quiz for a micro-lesson."""
        response = self.quizzes_table.query(
            IndexName='MicroLessonQuizzesIndex',
            KeyConditionExpression=Key('micro_lesson_id').eq(micro_lesson_id)
        )
        items = response.get('Items', [])
        return self._deserialize_item(items[0]) if items else None
    
    # Engagement tracking
    async def track_engagement(self, engagement_data: Dict[str, Any]) -> Dict[str, Any]:
        """Track user engagement event."""
        engagement_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        
        item = {
            'engagement_id': engagement_id,
            'timestamp': now.isoformat(),
            **engagement_data
        }
        
        serialized_item = self._serialize_item(item)
        self.user_engagement_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_user_engagement(self, user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Get user engagement history."""
        response = self.user_engagement_table.query(
            IndexName='UserEngagementIndex',
            KeyConditionExpression=Key('user_id').eq(user_id),
            Limit=limit,
            ScanIndexForward=False  # Most recent first
        )
        return [self._deserialize_item(item) for item in response.get('Items', [])]
    
    async def get_quiz_by_id(self, quiz_id: str) -> Optional[Dict[str, Any]]:
        """Get quiz by ID."""
        response = self.quizzes_table.get_item(Key={'quiz_id': quiz_id})
        return self._deserialize_item(response.get('Item')) if 'Item' in response else None
    
    async def update_quiz(self, quiz_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update quiz data."""
        updates['updated_at'] = datetime.now(timezone.utc).isoformat()
        
        update_expression = "SET "
        expression_values = {}
        
        for key, value in updates.items():
            update_expression += f"#{key} = :{key}, "
            expression_values[f":{key}"] = self._serialize_item(value)
        
        update_expression = update_expression.rstrip(", ")
        expression_names = {f"#{key}": key for key in updates.keys()}
        
        response = self.quizzes_table.update_item(
            Key={'quiz_id': quiz_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_names,
            ExpressionAttributeValues=expression_values,
            ReturnValues='ALL_NEW'
        )
        
        return self._deserialize_item(response['Attributes'])
    
    # Chat history operations
    async def create_chat_session(self, session_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new chat session."""
        session_id = session_data.get('session_id', str(uuid.uuid4()))
        now = datetime.now(timezone.utc)
        
        # Calculate TTL (30 days from now)
        ttl = int((now.timestamp() + (30 * 24 * 60 * 60)))
        
        item = {
            'session_id': session_id,
            'created_at': now.isoformat(),
            'updated_at': now.isoformat(),
            'messages': [],
            'ttl': ttl,
            **session_data
        }
        
        serialized_item = self._serialize_item(item)
        self.chat_history_table.put_item(Item=serialized_item)
        return self._deserialize_item(serialized_item)
    
    async def get_chat_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get chat session by ID."""
        response = self.chat_history_table.get_item(Key={'session_id': session_id})
        return self._deserialize_item(response.get('Item')) if 'Item' in response else None
    
    async def update_chat_session(self, session_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update chat session data."""
        updates['updated_at'] = datetime.now(timezone.utc).isoformat()
        
        update_expression = "SET "
        expression_values = {}
        
        for key, value in updates.items():
            update_expression += f"#{key} = :{key}, "
            expression_values[f":{key}"] = self._serialize_item(value)
        
        update_expression = update_expression.rstrip(", ")
        expression_names = {f"#{key}": key for key in updates.keys()}
        
        response = self.chat_history_table.update_item(
            Key={'session_id': session_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_names,
            ExpressionAttributeValues=expression_values,
            ReturnValues='ALL_NEW'
        )
        
        return self._deserialize_item(response['Attributes'])
    
    async def add_chat_message(
        self, 
        session_id: str, 
        user_id: str, 
        user_message: str, 
        ai_response: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Add a message to chat session."""
        now = datetime.now(timezone.utc)
        
        # Get existing session or create new one
        session = await self.get_chat_session(session_id)
        
        if session:
            messages = session.get('messages', [])
        else:
            # Create new session
            await self.create_chat_session({
                'session_id': session_id,
                'user_id': user_id
            })
            messages = []
        
        # Add new messages
        messages.extend([
            {
                'role': 'user',
                'content': user_message,
                'timestamp': now.isoformat()
            },
            {
                'role': 'assistant',
                'content': ai_response,
                'timestamp': now.isoformat(),
                'metadata': metadata or {}
            }
        ])
        
        # Keep only recent messages (last 50)
        if len(messages) > 50:
            messages = messages[-50:]
        
        # Update session with new messages
        await self.update_chat_session(session_id, {
            'messages': messages,
            'user_id': user_id
        })
    
    async def get_user_chat_sessions(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent chat sessions for a user."""
        # Note: This would require a GSI on user_id in a real implementation
        # For now, we'll return an empty list as this is not critical for the core functionality
        return []


# Global service instance
db_service = DynamoDBService()